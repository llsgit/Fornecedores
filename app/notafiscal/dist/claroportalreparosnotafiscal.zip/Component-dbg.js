// eslint-disable-next-line no-undef
sap.ui.define(['sap/fe/core/AppComponent'], function(AppComponent) {
    'use strict';

    return AppComponent.extend("claro.portalreparos.notafiscal.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
